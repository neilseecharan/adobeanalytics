
## Virtual Report Suites

### Example 1

The following is an example request body to create a virtual report suite:

```json
{
  "name": "VRS example",
  "parentRsid": "example",
  "segmentList": [
    "5543e358300456e42411509e",
    "536bfce4e4b06d874b0ca4c3"
  ],
  "timezone": 7
}
```
